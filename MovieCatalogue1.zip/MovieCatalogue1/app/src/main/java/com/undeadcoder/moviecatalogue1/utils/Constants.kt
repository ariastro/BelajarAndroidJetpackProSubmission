package com.undeadcoder.moviecatalogue1.utils

object Constants {

    const val MOVIES = "MOVIES"
    const val TV_SHOWS = "TV_SHOWS"

}
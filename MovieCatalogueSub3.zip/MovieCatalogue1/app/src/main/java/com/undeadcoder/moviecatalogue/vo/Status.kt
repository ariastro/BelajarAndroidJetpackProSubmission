package com.undeadcoder.moviecatalogue.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}
package com.undeadcoder.moviecatalogue.utils

object Constants {

    const val MOVIES = "MOVIES"
    const val TV_SHOWS = "TV_SHOWS"

    const val TIME_OUT = 30L

    const val DATABASE_NAME = "MovieCatalogueDB"

}